import Info from "./info";
import React from "react";
import '../App.css';

export default function User() {
    return(
        <div class="center">
            <h1> Ini Halaman User </h1>
            <Info />
        </div>
    );
}